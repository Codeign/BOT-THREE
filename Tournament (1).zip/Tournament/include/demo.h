void set_wheel_ticks(int left, int right);
void spin_motor(int port, int ticks, int speed);
void reckless_drive(float distance, int speed);
void reckless_turn(float degree, int speed);
double servo_start_time;
void d_drive(float distance, float speed);
void d_line_follow(float distance, float speed, int port, char side);
void d_right_turn(float degree, float speed, double radius);
void d_left_turn(float degree, float speed, double radius);