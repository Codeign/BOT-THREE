#include </home/root/Documents/KISS/GCER/Tournament/src/Functions.c>
void  red_cube();
void sort_poms();