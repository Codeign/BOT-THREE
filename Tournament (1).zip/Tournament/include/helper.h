
void viprint(int val);
void vfprint(float val);
float lerp(float start, float finish, float progress);
void clear_wheels();
//change the distance that the robot accels and deccels
void set_accel_window(float distance);

void light(int port);

//function that takes the error value received from the line follow sensor and gives back a radius for the turn
float line_follow_calculate_radius(int error_value, float max_radius, float min_radius);

//takes the speed of the origin and get the individual wheel speeds
float * calculate_wheel_speed(float radius, float speed);
//position calculate_location_change(double right_movement, double left_movement, double theta, float speed);
void start_chain(int size);

float calculate_speed_ramp(float final_dist, float current_dist);
void viprint(int val);
void vfprint(float val);
float lerp(float start, float finish, float progress);
float analog_avg(int port, int loops);