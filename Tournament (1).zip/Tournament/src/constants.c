#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>
float left_speed=50;
float right_speed=50;
int create_in_use = 0;

float wheel_circumference = 17.45547;
float distance_between_wheels = 11.43;
float right_wheel_tpr = 1771;
float left_wheel_tpr = 1660;
//current wheel ratios from test; right is 1.067
float right_wheel_tpc = 0;
float left_wheel_tpc = 0;
float pivot = 23.5/2;

float max_drive_speed = 100;

float grey_value = 3200;
float black_and_white_diff = 100;
float minimum_line_follow_radius = 30;
float maximum_line_follow_radius = 1000;
float used_tape_width = 5.08;

float accel_distance = 3.4;
float accel_deg = 15/57.296;

int servo_desired[4] = {-1,-1,-1,-1};
int servo_current[4] = {-1,-1,-1,-1};
float servo_time[4] = {-1,-1,-1,-1};
double servo_finish_time[4];

float create_right_speed = 0;
float create_left_speed = 0;

int create_lowest_speed = 40;



int chain_size = -1;
int chain = -1;