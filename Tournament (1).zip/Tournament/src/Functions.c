#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>
int sort(int position) //Alex's code (don't expect it to actually work or look functional)
{
    //int sort must be defined somewhere
    int l = 4095;
    int r = 1;
   // int m = 2047;
    int dir = 1;
    int sorter=0;
    int sort=2;
    if (position == l)
    {
        
        while (analog(sorter) < 4094)
        {
            mav(sort,100*dir);
        }
    }//end l if
    else if (position == r){
        while (analog(sorter) > 1)
        {
            mav(sort,-100*dir);
        }
    }//end r if
    else
    {
        while (analog(sorter) < 2046)
        {
            mav(sort, 100*dir);
        }
        while (analog(sorter) > 2048)
        {
            mav(sort, -100*dir);
        }
    }// end m if
    return 1;
}
// void noodle_grab(){
//	move(-1000,-1000);// backup to reset on hortizonal line.
//  msleep();
//  square_up();// backup line
//  move(-1000,-1000);// back up enough so we can turn left and prevent a dead spot.
//   msleep();
//  left_turn();
//  move(1000,1000); // drive to middle vertical line.
//  msleep();
//square_up (); end of line square up
//   move(1000,1000);// slight drive so we can square up in middle of demo starting box.
//msleep();
//right_turn();// should be facing south towards demo box
//  square_up();// square up so bot faces even
//move(); slight drive so we can grab noodles 
//  left_turn(); slight left turn to pick up middle left green noodle
//smart_Servo or whatever to grab noodle.
//move(); slight backup to turn right  to drop off noodle.
//	right_turn(); roughly 90 degree  turn 
//square_up(); end or beginging line.
//smart servo to open claw to drop thing off.
//move(); backup to square up again.
// left_turn(); facing south once again.
//move(); backup so we can square up north line of demo bot.
//  msleep();
//square_up(); end of line.
//move(); approach rack again.
//   right_turn() slight right to pick up middle right noodle.
//smart_servo(); close claw.
//    move();// back up so we can turn right.
//    turn_right();// facing west.
//    square_up(); west tape of demo bot square up
// move(); little less than last drive so noodles dont affect each other
//msleep();
// smart_servo(); claw open.
// move(); backup 
//msleep();
//  square_up(); end or begining line square up.
//   left_turn(); slight 60 degrees left so can pick up noodles.
// move(); approach last noodle.
//    msleep();
//smart_Servo(); close claw
//   move(); backup to turn left.
//   right_turn 60 degrees, 
//square_up();
//     move(); make sure enough room for each noodle.
//msleep();
//    smart_servo open claw


//void red_cube(){
// grab_red_cube(){ // Function for grabbing red cube 
//  right_turn(); // Turning Right in the starting box.
//square_up(); // square up on right starting box black line, Can either do end of line or begining of line.
//move(-1000,-1000); // This backup is optinal, but can perform double square up.
//   msleep(700); msleep for drive
//  square_up(); double square up, should be squared up, end of line or begining.
// move(1000,1000);// Start drive from squared up line to deterimed point, getting ready to turn.
//    msleep // msleep from drive.
// move(0,0);// freeze command
// right_turn(); // turning right 45 to grab cube.
// smart_servo,slow_servo to servo position to grab the cube.
// left_turn // This turn makes us straight facing the right hand side of the board.
// move(-1000,-1000)// This backup moves us back and lets us move the claw up with the red cube in the claw.
// msleep();
//}

//void sort_poms(){
// left_turn(); // facing last group of poms.
// move(-1000,-1000);
//msleep(1000);
// phy_square_up(); // whatever u need to do to square up on the back wall with sensors.
// move(1000,1000); // Pull up distance deterimed by bot size and wherever we need to do the sort.
// msleep(); // msleep for drive.
// move_sort // whatever function you use to sort the last stack of poms.
// square_up// This is optinal but recommeded.
// move(-1000,-1000); 
// msleep(1000);
//  left_turn(); You can either attack the next set of poms from a 45 or 90 degree angle depending on how fast you want to do.
// move_sort(); Sort poms, 2nd to last poms
// move(1000,1000);// Drive to next set of poms.
// msleep();
//  move_sort(); 2 stack of green poms
// move(1000,1000); drive to stack of red poms
///// msleep();   ^
///move_sort(); stack of red poms should be sorted by now. THE ONES IN FRONT OF STARTING BOX
//move(1000,1000); driving to first 2 stack of poms, from left to right.
//msleep();
// move_sort(); sorting 2 green poms next to starting box
//move(1000,1000);
//msleep() ^
// move_sort(); this should be the stack of 2 red pom.
// move(1000,1000); drive to stack of 1 green pom
// msleep();
// move_sort(); // this should be the stack of 1 green pom sorted.
// move(1000,1000); driving to 1 red pom stack
// move_sort(); // single red sorted
// move(1000,1000); //driving to 2nd group of poms from left to right.
//msleep();
//move_sort(); /// green sorted.
//move(1000,1000); Driving to first set of red poms.
//msleep();
//left_turn(); Turning to face create box.
//move(1000,1000);
//msleep();
// unsort_red_poms_into_starting_box();
//move(-1000,-1000); backup and square up incoming
//msleep();
//square_up(); end of line ending
// left_turn(); facing east of board.
//smart_servo or whatever function to put red cube in place.
//move(1000,1000); // Driving to drop off greens, DISTANCE UNKNOWN AT THIS TIME.
// msleep();
//    right_turn();// facing south of board. getting ready to drop off green poms.
// drop_off_green_poms(); dropping off green poms
// SORT COMPLETE HERE with red cube in place.
//}





