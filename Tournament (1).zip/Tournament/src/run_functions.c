#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>
#include <run_functions.h>
int sorter=1;
int sort_diag(){
    int ab0,bc0,cd0;
    int sort = 1;
    int time = 300;
    int position;
    int X = analog(sort);

    if (analog(sort) < 2) {
        position = 1;
    } else if (analog(sort) > 4094) {
        position = 2;
    } else {
        position = 3;
    }
    cmpc(sorter);

    switch (position) {
        case 1: // if less than 2

            mav(sort, 150);
            msleep(time);
            mav(sort, 0);
            msleep(time); // motor has moved, supposedly
            if (gmpc(sorter) == 0) {
                printf("MOTOR NOT PLUGGED IN");
                return 0;
            }
            if (X > 2) {
                return 1;
            }
            mav(sort, -150);
            msleep(2 * time);
            mav(sort, 0);
            msleep(time);
            if (X > 2) {
                return -1;
            } else {
                printf("ANALOG NOT PLUGGED IN OR BROKE");
            }
            // nothing below here, everything above is that slider
        case 2:
            mav(sort, -150);
            msleep(time);
            mav(sort, 0);
            msleep(time); // motor has moved, supposedly
            if (gmpc(sorter) == 0) {
                printf("MOTOR NOT PLUGGED IN");
                return 0;
            }
            if (4094 > X) {
                return -1;
            }
            mav(sort, 150);
            msleep(2 * time);
            mav(sort, 0);
            msleep(time);
            if (X < 4094) {
                return -1;
            } else {
                printf("ANALOG NOT PLUGGED IN OR BROKE");
            }
        case 3:
            {
                printf("i am in the correct case");
                ab0 = analog(sort);
                msleep(5);
                bc0 = analog(sort);
                msleep(5);
                cd0 = analog(sort);
                msleep(5);
                if (ab0 != bc0 || bc0 != cd0) {
                    printf("ANALOG NOT PLUGGED IN");
                    return 0;
                }
                int store = analog(sorter);
                mav(sort, -150);
                msleep(time);
                mav(sort, 0);
                msleep(time);
                if (gmpc(sorter) == 0) {
                    printf("MOTOR NOT PLUGGED IN");
                    return 0;
                }

                if (analog(sorter)> store) {
                    return -1;
                }
                if (analog(sorter)< store) {
                    return 1;
                }
                // nothing below here, everything above is that slider
            }}
    return 1;
}

int LEFT = 0;
int RIGHT = 4095;
int move_sorter(int value, int holder)
{
    printf("______%d sorter direction_______",holder);
    if (value>analog(sorter))
    {

        mav(sorter,(150*holder*1));
        while(analog(sorter)<value){ //pausing loop, intentionally left blank
        }
        mav(sorter,0);
        msleep(30);//active freeze

    }
    else
    {
        mav(sorter,-150*holder);
        while(analog(sorter)>value){ //pausing loop, intentionally left blank
        }
        mav(sorter,0);
        msleep(30);//active freeze
      

    }

    return 1;//courtesy and trivial return
}
