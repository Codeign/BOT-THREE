#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>
#include <run_functions.h>
#include <nonPRL.h>
int main(){
    int sorter_direction = sort_diag();
    	printf("%d",sorter_direction);
    //spin_motor(left, 1740, 500);
    //msleep(3000);
    //spin_motor(left, 1800, -500);
    //set_wheel_ticks(1740, 1800);//left is 1800 in reverse 
    //center_turn(left,90);
    //msleep(3000);
    //center_turn(right,90);
    Wheel_Calibration();
    //square_up(2,600);
    //square_up(1,600);
    drive_to(5);
    //center_turn(right, 90);
    
    //d_drive(100,100);
    return 0;
}
