#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <nonPRL.h>
#include <kipr/wombat.h>
//float wheel_circumference = 17.45547;
//float distance_between_wheels = 11.43;
//desired_degrees/360 7*pi
//float D_Wheel_Diameter=2.755905;//this is now a define

float tape_width = 1.88;
float forward_right=215.5;//take this out later...197.9
float backward_right=215.5;
float forward_left=215.5;//take values out later....199.7 226 magic tti 0.985 magic speed
float backward_left=215.5;//adjust this for ending
int L_coefficient=0;
int R_coefficient=0;
int max_speed = 870;
//this is the wheel calibration function
void drive_to(float inch){
    float left_desired;
    float right_desired;
    if(inch>0)
    {
        L_coefficient =1;
        R_coefficient =1;
        left_desired= inch*L_coefficient*forward_left;
    	right_desired= inch*R_coefficient*forward_right;
    }
    if(inch<0)
    {
        L_coefficient =-1;
        R_coefficient =-1;
        left_desired= inch*L_coefficient*backward_left;
    	right_desired= inch*R_coefficient*backward_right;
    }
    cmpc(right_wheel);
    cmpc(left_wheel);
     printf("desired: %f, %f\n",left_desired, right_desired);
    turn_a_cel();
    while(fabs(gmpc(right_wheel))<(fabs(right_desired)-200)){
    	move(L_coefficient*870*(forward_right/forward_left),R_coefficient*870);//this is the Luke mid section of base travel
    }//was .86..this is the arc
    printf("%d_____%d\n",gmpc(left_wheel),gmpc(right_wheel)); 
   
   while(fabs(gmpc(left_wheel))<fabs(left_desired) || fabs(gmpc(right_wheel))<fabs(right_desired)){//this is the deceleration component
        int R_speed = 2 * (fabs(right_desired) - fabs(gmpc(right_wheel))+10);
        //if(R_speed>max_speed){R_speed=max_speed;}
        int L_speed = 2 * (fabs(left_desired) - fabs(gmpc(left_wheel))+10);
        //if(L_speed>max_speed){L_speed=max_speed;}
        
        
    	if(fabs(gmpc(left_wheel))<fabs(left_desired)&&fabs(gmpc(right_wheel))<fabs(right_desired)){
        	move(L_speed*L_coefficient,R_speed*R_coefficient);
        }
        if(fabs(gmpc(left_wheel))<fabs(left_desired)){
        	move(L_speed*L_coefficient,0);
        }
		if(fabs(gmpc(right_wheel))<fabs(right_desired)){
        	move(0,R_speed*R_coefficient);
        }
    }
    move(0,0);
    msleep(50);
    printf("________Final_______"); 
    printf("%d_____%d\n",gmpc(left_wheel),gmpc(right_wheel)); 
}

void Wheel_Calibration()
{
    square_up(2,400);
    cmpc(right_wheel);
    cmpc(left_wheel);
    turn_a_cel();
    custom_square_up(1,400);
    msleep(500);
    forward_left = 1*(gmpc(left_wheel)/tape_width);
    forward_right = 1*(gmpc(right_wheel)/tape_width);
    printf("left:%f\n",forward_left);
    L_coefficient=-1;
    R_coefficient=-1;
    cmpc(right_wheel);
    cmpc(left_wheel);
    turn_a_cel();
    custom_square_up(1,-400);
    backward_left = 1.1*(gmpc(left_wheel)/tape_width);
    backward_right = 1.1*(gmpc(right_wheel)/tape_width);
    //print all the data
    printf("left forward:%f\n",forward_left);
    printf("right forward:%f\n",forward_right);
    printf("left backward:%f\n",backward_left);
    printf("right backward:%f\n",backward_right);

}
float D_Wheel_Circumference= D_Wheel_Diameter*pi;
float D_mid_turn_circumference = D_Distance_Between_Wheels * pi;
int digital_left =1;
int digital_right = 0;
int analog_white = 1700;
int left_IR = 0;
int right_IR = 2;
int stop = 0;
void move(int l_speed,int r_speed)
{//basic moving function thats based off mav
    mav(right_wheel,r_speed);
    mav(left_wheel,l_speed);
}


int holder_r;
int holder_l;
void turn_a_cel(){
    float L_turn_speed;
    float R_turn_speed;
    float curr_time = seconds(); 
    float init_time = seconds();
    while( (curr_time - init_time) < .2 ){
        curr_time = seconds();  
        R_turn_speed = (R_coefficient)*3.4 * ((curr_time - init_time) * 1000);
        L_turn_speed = (L_coefficient)*3.4 * ((curr_time - init_time) * 1000);
        move(L_turn_speed,R_turn_speed); 
    }
    holder_r=R_turn_speed;
    holder_l=L_turn_speed;
}
int left=left_wheel;
int right=right_wheel;
int center_turn(int direction, int desired_degrees){

    float desired_ticks_L = (left_wheel_tpr/360) * desired_degrees*2.82;//this is the coefficient
    float desired_ticks_R = (right_wheel_tpr/360) * desired_degrees*2.82;//twice
    cmpc(right_wheel);
    cmpc(left_wheel);
    
    if(direction == left)
    { L_coefficient = -1;
     R_coefficient = 1;
     desired_ticks_L = (left_wheel_tpr/360) * desired_degrees*2.9;//this is the coefficient
     printf("left:%f\n",desired_ticks_L);
     printf("right%f\n",desired_ticks_R);}
    else if(direction ==right) 
    { R_coefficient = -1;
     L_coefficient = 1;
     printf("left:%f\n",desired_ticks_L);
     printf("right:%f\n",desired_ticks_R);
    }
    else
    {printf("CHOOSE A DIRECTION IN PARAMETER 1");}
    turn_a_cel();//accelerate into speed(takes .2 seconds)<<<====if robot goes straight, direction Parameter is not set
    // while(gmpc(left_wheel) <= (fabs(desired_ticks_L)-500) && gmpc(right_wheel) <= (fabs(desired_ticks_R)-500))
    //{

    //    mav(left_wheel,L_turn_speed*L_coefficient);
    //   mav(right_wheel,R_turn_speed*R_coefficient);
    //  }  
    while(fabs(gmpc(left_wheel)) < desired_ticks_L || fabs(gmpc(right_wheel)) < desired_ticks_R)
    {

        int R_speed = 2.4 * (desired_ticks_R - fabs(gmpc(right_wheel)) + 10);
        if(R_speed>max_speed){R_speed=max_speed;}
        int L_speed = 2.4 * (desired_ticks_L - fabs(gmpc(left_wheel)) + 10);
        if(L_speed>max_speed){L_speed=max_speed;}
        move(L_speed*L_coefficient,R_speed*R_coefficient);

    }
    move(0,0);
    msleep(50);
    //printf("max right speed:%d\n",holder_r);
    //printf("max left speed:%d\n",holder_l);
    return 1;
}

void custom_square_up(int ending,int speed){//pulled from 2019 Botball, circa Jacob Ross and Tyler Maenza
    int black_speed = 400;
    if(speed > 0 && speed < 600){
        black_speed = 1.2*speed;
    }
    else{black_speed = 0.25*speed;}
    if(ending == 1 || ending == 2){
        while(1){
            if(analog(left_IR)<analog_white && analog(right_IR)<analog_white){
                move(speed,speed);
            }
            if(analog(right_IR)>analog_white){
                move(speed,stop);
            }
            if(analog(left_IR)>analog_white){
                move(stop,speed);
            }
            if(analog(left_IR)>analog_white && analog(right_IR)>analog_white) {
                move(stop,stop);
                break;
            }
        }
    }
    if(ending == 3){
        ao();
    }
    switch(ending){
        case 3:
            {
                while(1){
                    if(digital(digital_right)==0 && digital(digital_left)==0){
                        move(speed,speed);
                    }
                    if(digital(digital_right)==1){
                        move(speed,stop);
                    }
                    if(digital(digital_left)==1){
                        move(stop,speed);
                    }
                    if(digital(digital_right)==1 && digital(digital_left)==1){
                        move(stop,stop);
                        break;
                    }
                }
            }
        case 1:
            {
                int l =0;
                int r = 0;
                while(1){
                    if(analog(left_IR)>analog_white && analog(right_IR)>analog_white){
                        move(black_speed,black_speed);
                    }
                    if(analog(left_IR)<analog_white){
                        move(stop,black_speed);
                        l=l+1;
                        if(l==1){
                        //forward_left = (gmpc(left_wheel)/tape_width);
                        }
                    }
                    if(analog(right_IR)<analog_white){
                        move(black_speed,stop);
                        r=r+1;
                        if(r==1){
                        //forward_right = (gmpc(right_wheel)/tape_width);
                        }
                    }
                    if(analog(left_IR)<analog_white && analog(right_IR)<analog_white){
                        move(stop,stop);
                        break;
                    }
                }
            }
        case 2:
            {
                while(1){
                    if(analog(left_IR)>analog_white && analog(right_IR)>analog_white){
                        move(-1*black_speed,-1*black_speed);
                    }
                    if(analog(left_IR)<analog_white){
                        move(stop,-1*black_speed);
                    }
                    if(analog(right_IR)<analog_white){
                        move(-1*black_speed,stop);
                    }
                    if(analog(left_IR)<analog_white && analog(right_IR)<analog_white){
                        move(stop,stop);
                        break;
                    }
                }
            }
    }
}//end of custom squareup

void square_up(int ending,int speed){//pulled from 2019 Botball, circa Jacob Ross and Tyler Maenza
    int black_speed = 870;
    if(speed > 0 && speed < 600){
        black_speed = 1.2*speed;
    }
    else{black_speed = 0.25*speed;}
    if(ending == 1 || ending == 2){
        while(1){
            if(analog(left_IR)<analog_white && analog(right_IR)<analog_white){
                move(speed,speed);
            }
            if(analog(right_IR)>analog_white){
                move(speed,stop);
            }
            if(analog(left_IR)>analog_white){
                move(stop,speed);
            }
            if(analog(left_IR)>analog_white && analog(right_IR)>analog_white) {
                move(stop,stop);
                break;
            }
        }
    }
    if(ending == 3){
        ao();
    }
    switch(ending){
        case 3:
            {
                while(1){
                    if(digital(digital_right)==0 && digital(digital_left)==0){
                        move(speed,speed);
                    }
                    if(digital(digital_right)==1){
                        move(speed,stop);
                    }
                    if(digital(digital_left)==1){
                        move(stop,speed);
                    }
                    if(digital(digital_right)==1 && digital(digital_left)==1){
                        move(stop,stop);
                        break;
                    }
                }
            }
        case 1:
            {
                while(1){
                    if(analog(left_IR)>analog_white && analog(right_IR)>analog_white){
                        move(black_speed,black_speed);
                    }
                    if(analog(left_IR)<analog_white){
                        move(stop,black_speed);
                    }
                    if(analog(right_IR)<analog_white){
                        move(black_speed,stop);
                    }
                    if(analog(left_IR)<analog_white && analog(right_IR)<analog_white){
                        move(stop,stop);
                        break;
                    }
                }
            }
        case 2:
            {
                while(1){
                    if(analog(left_IR)>analog_white && analog(right_IR)>analog_white){
                        move(-1*black_speed,-1*black_speed);
                    }
                    if(analog(left_IR)<analog_white){
                        move(stop,-1*black_speed);
                    }
                    if(analog(right_IR)<analog_white){
                        move(-1*black_speed,stop);
                    }
                    if(analog(left_IR)<analog_white && analog(right_IR)<analog_white){
                        move(stop,stop);
                        break;
                    }
                }
            }
    }
}